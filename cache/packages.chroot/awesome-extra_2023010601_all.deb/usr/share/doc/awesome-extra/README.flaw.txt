Flaw is a LUA object oriented library providing a thin abstraction
layer above awesome widgets. It is aimed at being simple and resources
efficient. See <http://david.soulayrol.name/projects/flaw/>.

Flaw requires luafilesystem. To learn more, please read the provided
flaw(7) man page. You can read it without installing it on the system
using one of the following commands:

  man -l flaw.7
  groff -t -mandoc -Tascii flaw.7 | less

Flaw also comes with inline documentation. If you have Luadoc
installed, you can use the following command to extract HTML
documentation pages.

  LUA_PATH="path_toflaw/doclet/html/?;;" luadoc -d html --nofiles *.lua

-- David Soulayrol <david.soulayrol AT gmail DOT net>