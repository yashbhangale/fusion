Compton
=======

This is forked from the original Compton because that seems to have become unmaintained. I'll merge pull requests as they appear upstream, as well as trying to fix bugs reported to upstream, or found by myself.

New features are not likely to be added, since I expect compton to become irrelevant in near future.

The original README can be found [here](README_orig.md)

You are welcomed to submit pull requests.
